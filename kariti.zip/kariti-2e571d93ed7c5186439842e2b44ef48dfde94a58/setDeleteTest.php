<?php


  function deleteTest($id_test){
    $sql_prova = "DELETE FROM prova WHERE id_prova = '".$id_test."'";
    $sql_gabarito = "DELETE FROM gabarito WHERE id_prova = '".$id_test."'";
    $sql_aluno_prova = "DELETE FROM aluno_prova WHERE id_prova = '".$id_test."'";
    try{
      //define PDO - tell about the database file
      $pdo = new PDO('sqlite:database.db');

      //Execute the query
      $pdo->exec($sql_prova);
      $pdo->exec($sql_gabarito);
      $pdo->exec($sql_aluno_prova);
      $message = '<font color="green">PROVA DELETADA COM SUCESSO</font><br>';

    }catch(PDOException $e){
      $message = '<font color="red">NÃO FOI POSSÍVEL DELETAR A PROVA</font><br>';
    }

    return $message;
  }

  $id_test = $_POST['id_test'];

  $_GET['message'] = deleteTest($id_test);

  header('Location: searchTest.php?message='.$_GET['message'])


 ?>
